DROP TABLE IF EXISTS `#__caadm_noticias`;
